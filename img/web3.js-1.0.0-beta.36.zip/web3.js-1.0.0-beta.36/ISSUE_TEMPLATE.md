<!---

Steps before creating an issue: 

1. I've read the documentation.
2. I was looking for an solution on stackoverflow or something else.
3. I was looking for an identical issue.

-->

#### Expected behavior

#### Actual behavior

#### Steps to reproduce the behavior

1. [First step]
2. [Second step]
3. [and so on...]

#### Logs

#### Versions
[NPM, Node, Web3.js, OS, device...]
