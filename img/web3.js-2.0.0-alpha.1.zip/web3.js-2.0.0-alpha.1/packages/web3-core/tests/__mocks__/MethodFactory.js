export default class MethodFactory {
    constructor() {}
}
