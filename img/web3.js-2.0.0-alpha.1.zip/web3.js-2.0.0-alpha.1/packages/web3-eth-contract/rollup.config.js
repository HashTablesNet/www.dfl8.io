import pkg from './package.json';
import rollupConfig from '../../rollup.config';

export default rollupConfig('Web3EthContract', pkg.name);
