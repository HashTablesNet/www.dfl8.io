export default class MethodModuleFactory {
    constructor() {}
}
