export default class Accounts {
    constructor() {
        this.wallet = [];
    }
    sign(data, privateKey) {}
    signTransaction(data, privateKey) {}
}
