export default class TransactionSigner {
    sign() {}
}
