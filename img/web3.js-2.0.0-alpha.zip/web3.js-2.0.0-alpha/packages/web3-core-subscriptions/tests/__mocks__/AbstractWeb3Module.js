export default class AbstractWeb3Module {
    constructor() {
        this.currentProvider = {};
    }
}
