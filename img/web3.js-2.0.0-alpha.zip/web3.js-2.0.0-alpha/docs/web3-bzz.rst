.. _bzz:

.. include:: include_announcement.rst

========
web3.bzz
========

The ``web3-bzz`` does no longer exists in the web3.js project. Check out the `Swarm Docs <http://swarm-guide.readthedocs.io/en/latest/>`_
for seeing possible alternatives to interact with the Swarm API.
