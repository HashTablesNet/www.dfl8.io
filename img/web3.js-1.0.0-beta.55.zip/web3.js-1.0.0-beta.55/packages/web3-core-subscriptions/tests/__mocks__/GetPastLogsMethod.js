export default class GetPastLogsMethod {
    constructor() {}
}
