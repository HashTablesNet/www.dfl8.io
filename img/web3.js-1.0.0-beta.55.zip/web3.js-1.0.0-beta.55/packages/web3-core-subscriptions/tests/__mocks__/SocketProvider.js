export default class SocketProvider {
    constructor() {}
    on() {}
    once() {}
    subscribe() {}
    removeAllListeners() {}
}
