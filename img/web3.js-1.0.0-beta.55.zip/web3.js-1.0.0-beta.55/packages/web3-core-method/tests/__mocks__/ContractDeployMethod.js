export default class ContractDeployMethod {
    constructor() {
        this.callback = null;
    }
    afterExecution() {}
}
