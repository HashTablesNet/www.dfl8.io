export default class CustomProvider {
    constructor() {
        this.host = 'CustomProvider';
        this.connection = {};
    }
    send(method, parameters) {}
}
